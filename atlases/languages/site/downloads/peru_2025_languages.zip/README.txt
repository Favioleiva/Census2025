PERU 2025 — PUBLISHED CHILDHOOD-LANGUAGE INDICATORS

dataset_distrital_1892.csv / .parquet: the mapped derivative (1,892 units).
dataset_distrital_1893.csv / .parquet: final indicators before aggregation
(1,893 source districts). These are distinct versions, never concatenate them.
ranking_nacional.csv / .parquet: final national ranking for 54 categories.
correspondencia_distrital.csv: explicit Sangani–Perené and geometry crosswalk.
diccionario_categorias.csv: preserved labels and public definitions.
metodologia.txt: denominator, map classes, geography and source limitations.
MANIFEST.json: sizes and SHA-256 checksums of every other archive member.

Read district_code as text, preserving leading zeros and original codes.
S5_P16_1..S5_P16_54 are category-1 counts; *_pct = 100 * count /
population_aged_3plus. Categories can overlap. Missing is not zero.
District tables include the denominator; original age tabulations are excluded.
Sangani is combined with Perené only in the 1,892-unit derivative; national
totals are unchanged. The 182 geographic population differences remain
unresolved. The official original dictionary was unavailable; labels come
from the preserved query/Excel evidence. No cross-census equivalence is assumed.

Statistical tables and the crosswalk are copied byte-for-byte from approved
outputs. Dictionary labels and definitions are preserved; local file paths
are replaced by the public source attribution. Raw downloads, intermediate
tables, internal reports and logs are not included in this publication.

Source: INEI, Censos Nacionales 2025, https://redatamcpv2025.inei.gob.pe/
External data and geographic redistribution rights are not inferred.
